#!/usr/bin/env zsh
# ==============================================================================
# Kimi Token Guardian - Local Quota & Rate Limit Watchdog (macOS 26 / zsh)
# Description: Native zsh audit and context optimizer for Kimi Code & Agents.
# ==============================================================================

set -eo pipefail

WORKSPACE="${2:-$(pwd)}"
THRESHOLD="${3:-75}"
WINDOW_MAX_TOKENS=2500000

log_info() { print "\033[1;32m[+] [KimiGuardian-macOS]\033[0m $1"; }
log_warn() { print "\033[1;33m[!] [WARNING]\033[0m $1"; }
log_crit() { print "\033[1;31m[-] [CRITICAL]\033[0m $1"; }

init_kimiignore() {
    local target_dir="$1"
    local ignore_file="$target_dir/.kimiignore"
    log_info "Creating macOS-optimized .kimiignore in: $target_dir"
    cat << IGN > "$ignore_file"
# === Kimi Code Context Pruning Rules (macOS 26) ===
.git/
.DS_Store
.AppleDouble
.LSOverride
node_modules/
.venv/
venv/
__pycache__/
dist/
build/
target/
*.o
*.dylib
*.wasm
*.png
*.jpg
*.jpeg
*.webp
*.zip
*.tar.*
*.min.js
*.min.css
*.map
package-lock.json
pnpm-lock.yaml
yarn.lock
Cargo.lock
*.log
coverage/
IGN
    log_info ".kimiignore created successfully!"
}

audit_workspace() {
    local target_dir="$1"
    log_info "Auditing workspace token footprint for macOS: $target_dir"
    if [[ ! -f "$target_dir/.kimiignore" ]]; then
        log_warn "No .kimiignore detected in workspace!"
        init_kimiignore "$target_dir"
    fi

    local total_files=0
    local total_bytes=0

    for f in $(find "$target_dir" -maxdepth 4 -type f ! -path "*/.*" ! -path "*/node_modules/*" ! -path "*/target/*" ! -path "*/dist/*" 2>/dev/null); do
        if [[ -f "$f" ]]; then
            total_files=$((total_files + 1))
            local sz=$(stat -f%z "$f" 2>/dev/null || echo 0)
            total_bytes=$((total_bytes + sz))
        fi
    done

    local est_tokens=$((total_bytes / 3))

    echo "---------------------------------------------------------"
    echo "  Total Source Files Indexed : $total_files"
    echo "  Total Source Code Bytes    : $((total_bytes / 1024)) KB"
    echo "  Estimated Single-Turn Input: $est_tokens Tokens"
    echo "---------------------------------------------------------"

    if (( est_tokens > 150000 )); then
        log_crit "Estimated single-turn prompt exceeds 150k tokens! Pruning required!"
    elif (( est_tokens > 60000 )); then
        log_warn "Single-turn prompt context is moderately large ($est_tokens tokens)."
    else
        log_info "Workspace context is optimal ($est_tokens tokens)."
    fi
}

case "${1:-audit}" in
    --init-ignore)
        init_kimiignore "$WORKSPACE"
        ;;
    --audit)
        audit_workspace "$WORKSPACE"
        ;;
    *)
        audit_workspace "$WORKSPACE"
        ;;
esac
