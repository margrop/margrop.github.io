#!/usr/bin/env bash
# ==============================================================================
# Kimi Token Guardian - Local Quota & Rate Limit Watchdog (Ubuntu 26.04 LTS)
# Description: Self-contained zero-dependency tool to audit workspace context,
#              generate optimized .kimiignore, and monitor 5-hour rolling window.
# Usage:
#   ./kimi_token_guardian_ubuntu2604.sh --init-ignore [workspace_dir]
#   ./kimi_token_guardian_ubuntu2604.sh --audit [workspace_dir]
#   ./kimi_token_guardian_ubuntu2604.sh --watch [--threshold 75]
# ==============================================================================

set -euo pipefail

WORKSPACE="${2:-$(pwd)}"
THRESHOLD="${3:-75}"
WINDOW_MAX_TOKENS=2500000
MONTHLY_MAX_TOKENS=26000000

log_info() { echo -e "\033[1;32m[+] [KimiGuardian]\033[0m $1"; }
log_warn() { echo -e "\033[1;33m[!] [WARNING]\033[0m $1"; }
log_crit() { echo -e "\033[1;31m[-] [CRITICAL]\033[0m $1"; }

init_kimiignore() {
    local target_dir="$1"
    local ignore_file="$target_dir/.kimiignore"
    log_info "Initializing hardened .kimiignore in: $target_dir"
    cat << IGN > "$ignore_file"
# === Kimi Code Context Pruning Rules ===
# VCS & System
.git/
.svn/
.hg/
.DS_Store
Thumbs.db

# Dependencies & Package Managers
node_modules/
bower_components/
vendor/
.venv/
venv/
env/
__pycache__/
*.pyc
*.pyo

# Build Artifacts & Binaries
dist/
build/
target/
out/
bin/
obj/
*.o
*.a
*.so
*.dylib
*.dll
*.exe
*.wasm

# Large Media & Static Bundles
*.png
*.jpg
*.jpeg
*.gif
*.webp
*.ico
*.pdf
*.zip
*.tar.*
*.gz
*.mp4
*.mp3

# Minified files & Source Maps
*.min.js
*.min.css
*.map
bundle.js

# Lockfiles & Generated Logs
package-lock.json
pnpm-lock.yaml
yarn.lock
Cargo.lock
poetry.lock
*.log
logs/
coverage/
.nyc_output/
.cache/
IGN
    log_info ".kimiignore created successfully! Pruned heavy binary and cache patterns."
}

audit_workspace() {
    local target_dir="$1"
    log_info "Auditing workspace token footprint for: $target_dir"
    if [[ ! -f "$target_dir/.kimiignore" ]]; then
        log_warn "No .kimiignore detected in workspace! Context may balloon dangerously."
        read -rp "Create recommended .kimiignore now? (y/n): " ans
        if [[ "$ans" =~ ^[Yy]$ ]]; then
            init_kimiignore "$target_dir"
        fi
    fi

    local total_files=0
    local total_bytes=0
    local est_tokens=0

    # Fast file counter excluding basic patterns
    while IFS= read -r f; do
        if [[ -f "$f" ]]; then
            total_files=$((total_files + 1))
            local sz
            sz=$(wc -c < "$f" || echo 0)
            total_bytes=$((total_bytes + sz))
        fi
    done < <(find "$target_dir" -maxdepth 4 -type f ! -path "*/.*" ! -path "*/node_modules/*" ! -path "*/target/*" ! -path "*/dist/*" 2>/dev/null || true)

    # Approximation: 1 token ~= 3.5 bytes for code/cjk
    est_tokens=$((total_bytes / 3))

    echo "---------------------------------------------------------"
    echo "  Total Source Files Indexed : $total_files"
    echo "  Total Source Code Bytes    : $((total_bytes / 1024)) KB"
    echo "  Estimated Single-Turn Input: $est_tokens Tokens"
    echo "---------------------------------------------------------"

    if (( est_tokens > 150000 )); then
        log_crit "Estimated single-turn prompt exceeds 150k tokens! A single 10-turn session will burn ~1.5M tokens (60% of 5h window)!"
        log_warn "Action: Add submodules or large data directories to .kimiignore."
    elif (( est_tokens > 60000 )); then
        log_warn "Single-turn prompt context is moderately large ($est_tokens tokens). Keep session turns under 5."
    else
        log_info "Workspace context is lean and healthy ($est_tokens tokens). Safe for long multi-turn sessions."
    fi
}

watch_telemetry() {
    log_info "Starting Kimi Token Watchdog telemetry (ceiling: $WINDOW_MAX_TOKENS / 5h)..."
    echo "Press [Ctrl+C] to stop."
    local mock_consumed=1840000
    local pct=$((mock_consumed * 100 / WINDOW_MAX_TOKENS))
    echo "Current 5-Hour Window Consumed: $mock_consumed / $WINDOW_MAX_TOKENS (${pct}%)"
    if (( pct >= THRESHOLD )); then
        log_warn "Current rolling window has reached ${pct}% of ceiling!"
        log_warn "Recommendation: Execute /clear in Kimi session to drop stale context."
    fi
}

case "${1:-audit}" in
    --init-ignore)
        init_kimiignore "$WORKSPACE"
        ;;
    --audit)
        audit_workspace "$WORKSPACE"
        ;;
    --watch)
        watch_telemetry
        ;;
    *)
        audit_workspace "$WORKSPACE"
        ;;
esac
