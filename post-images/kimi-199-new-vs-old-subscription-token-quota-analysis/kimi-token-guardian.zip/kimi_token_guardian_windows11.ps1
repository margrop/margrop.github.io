# ==============================================================================
# Kimi Token Guardian - Local Quota & Rate Limit Watchdog (Windows 11 PowerShell)
# ==============================================================================
[CmdletBinding()]
param (
    [string]$Action = "audit",
    [string]$Workspace = (Get-Location).Path,
    [int]$Threshold = 75
)

$WindowMaxTokens = 2500000

function Write-Info ($msg) { Write-Host "[+] [KimiGuardian-Win11] $msg" -ForegroundColor Green }
function Write-WarningMsg ($msg) { Write-Host "[!] [WARNING] $msg" -ForegroundColor Yellow }
function Write-Critical ($msg) { Write-Host "[-] [CRITICAL] $msg" -ForegroundColor Red }

function Initialize-KimiIgnore ($dir) {
    $ignorePath = Join-Path $dir ".kimiignore"
    Write-Info "Creating Windows 11 .kimiignore in: $dir"
    $rules = @"
# === Kimi Code Context Pruning Rules (Windows 11) ===
.git/
.vs/
.vscode/
bin/
obj/
node_modules/
.venv/
venv/
__pycache__/
dist/
build/
target/
*.exe
*.dll
*.pdb
*.wasm
*.png
*.jpg
*.jpeg
*.webp
*.zip
*.tar.*
*.min.js
*.min.css
*.map
package-lock.json
pnpm-lock.yaml
yarn.lock
Cargo.lock
*.log
coverage/
"@
    Set-Content -Path $ignorePath -Value $rules -Encoding utf8
    Write-Info ".kimiignore created successfully!"
}

function Audit-Workspace ($dir) {
    Write-Info "Auditing workspace token footprint for Windows: $dir"
    $ignorePath = Join-Path $dir ".kimiignore"
    if (-not (Test-Path $ignorePath)) {
        Write-WarningMsg "No .kimiignore detected in workspace!"
        Initialize-KimiIgnore $dir
    }

    $excludeDirs = @("node_modules", "dist", "build", "target", ".git", ".vs", "bin", "obj", ".venv")
    $files = Get-ChildItem -Path $dir -Recurse -File -ErrorAction SilentlyContinue | Where-Object {
        $path = $_.FullName
        $skip = $false
        foreach ($ex in $excludeDirs) {
            if ($path -like "*\$ex\*") { $skip = $true; break }
        }
        -not $skip
    }

    $totalBytes = ($files | Measure-Object -Property Length -Sum).Sum
    if (-not $totalBytes) { $totalBytes = 0 }
    $fileCount = ($files | Measure-Object).Count
    $estTokens = [math]::Round($totalBytes / 3)

    Write-Host "---------------------------------------------------------" -ForegroundColor Cyan
    Write-Host "  Total Source Files Indexed : $fileCount"
    Write-Host "  Total Source Code Bytes    : $([math]::Round($totalBytes / 1024)) KB"
    Write-Host "  Estimated Single-Turn Input: $estTokens Tokens"
    Write-Host "---------------------------------------------------------" -ForegroundColor Cyan

    if ($estTokens -gt 150000) {
        Write-Critical "Estimated prompt exceeds 150k tokens! Single 10-turn session will burn ~1.5M tokens!"
    } elseif ($estTokens -gt 60000) {
        Write-WarningMsg "Context is moderately large ($estTokens tokens). Keep session turns under 5."
    } else {
        Write-Info "Workspace context is optimal ($estTokens tokens)."
    }
}

switch ($Action.ToLower()) {
    "init-ignore" { Initialize-KimiIgnore $Workspace }
    "audit"       { Audit-Workspace $Workspace }
    default       { Audit-Workspace $Workspace }
}
