#!/usr/bin/env bash
# ==============================================================================
# Kimi 3.1 & k3d1-agent Gateway Health & Canary Probe for Ubuntu 26.04 LTS
# Zero-dependency: Uses native curl, awk, and standard GNU coreutils.
# ==============================================================================

set -euo pipefail

AGENT_MODE=false
API_KEY="${MOONSHOT_API_KEY:-sk-anonymous-probe-token}"
MODEL="k3d1-agent"
ENDPOINT="https://api.moonshot.cn/v1"

POSITIONAL_ARGS=()
while [[ $# -gt 0 ]]; do
    case "$1" in
        --agent-mode|--json)
            AGENT_MODE=true
            shift
            ;;
        --model=*)
            MODEL="${1#*=}"
            shift
            ;;
        --endpoint=*)
            ENDPOINT="${1#*=}"
            shift
            ;;
        *)
            POSITIONAL_ARGS+=("$1")
            shift
            ;;
    esac
done

if [ ${#POSITIONAL_ARGS[@]} -ge 1 ]; then
    MODEL="${POSITIONAL_ARGS[0]}"
fi
if [ ${#POSITIONAL_ARGS[@]} -ge 2 ]; then
    ENDPOINT="${POSITIONAL_ARGS[1]}"
fi

log_info() {
    if [ "$AGENT_MODE" = false ]; then
        echo -e "\033[36m[*] $1\033[0m"
    fi
}
log_success() {
    if [ "$AGENT_MODE" = false ]; then
        echo -e "\033[32m[OK] $1\033[0m"
    fi
}
log_warn() {
    if [ "$AGENT_MODE" = false ]; then
        echo -e "\033[33m[!] $1\033[0m"
    fi
}
log_error() {
    if [ "$AGENT_MODE" = false ]; then
        echo -e "\033[31m[ERROR] $1\033[0m"
    fi
}

TIMESTAMP=$(date -u +"%Y-%m-%dT%H:%M:%SZ")
PLATFORM="Ubuntu 26.04 LTS (Bash 5.3)"

log_info "Probing Moonshot AI Gateway via Ubuntu 26.04 network stack..."

# Test TLS handshake and connect time
CONNECT_TIME=$(curl -s -w "%{time_connect}\n" -o /dev/null -s "https://api.moonshot.cn" || echo "0.0")
CONNECT_MS=$(awk "BEGIN {print int($CONNECT_TIME * 1000)}")
log_success "TCP/TLS Handshake completed: ${CONNECT_MS} ms"

# Query Canary Model Route
log_info "Dispatching HTTP/2 probe for model: ${MODEL}"

HEADER_DUMP=$(mktemp)
BODY_DUMP=$(mktemp)
trap 'rm -f "$HEADER_DUMP" "$BODY_DUMP"' EXIT

HTTP_CODE=$(curl -s -w "%{http_code}" \
    -D "$HEADER_DUMP" \
    -o "$BODY_DUMP" \
    --max-time 15 \
    -X POST "${ENDPOINT}/chat/completions" \
    -H "Authorization: Bearer ${API_KEY}" \
    -H "Content-Type: application/json" \
    -d "{\"model\":\"${MODEL}\",\"messages\":[{\"role\":\"user\",\"content\":\"ping\"}],\"reasoning_effort\":\"low\",\"max_tokens\":16,\"stream\":false}" || echo "000")

CANARY_DETECTED=false
if grep -qi "x-moonshot-canary" "$HEADER_DUMP"; then
    CANARY_DETECTED=true
fi

VALVE_STATUS="NORMAL"
if [ "$HTTP_CODE" -eq 200 ]; then
    log_success "Model ${MODEL} is ONLINE & ACCESSIBLE (200 OK)!"
elif [ "$HTTP_CODE" -eq 403 ]; then
    log_warn "Model ${MODEL} route confirmed active in staging (403: Insider Token Required)!"
elif [ "$HTTP_CODE" -eq 404 ]; then
    log_warn "Model ${MODEL} route returned 404 (Not staged on target edge cluster)."
elif [ "$HTTP_CODE" -eq 429 ]; then
    log_error "5-Hour Rolling Rate Limit Exceeded (429 Too Many Requests)!"
    VALVE_STATUS="THROTTLED"
else
    log_warn "Endpoint returned status: HTTP ${HTTP_CODE}"
fi

if [ "$AGENT_MODE" = true ]; then
    cat << EOF
{
  "timestamp": "${TIMESTAMP}",
  "platform": "${PLATFORM}",
  "target_endpoint": "${ENDPOINT}",
  "probed_model": "${MODEL}",
  "tls_handshake_ms": ${CONNECT_MS},
  "http_status": ${HTTP_CODE},
  "canary_detected": ${CANARY_DETECTED},
  "quota_valve_status": "${VALVE_STATUS}",
  "recommended_tier": "high"
}
EOF
else
    echo ""
    echo "=================== Diagnostic Summary ==================="
    echo "Platform        : ${PLATFORM}"
    echo "Probed Model    : ${MODEL}"
    echo "HTTP Status     : ${HTTP_CODE}"
    echo "Canary Detected : ${CANARY_DETECTED}"
    echo "Quota Status    : ${VALVE_STATUS}"
    echo "Handshake Latency: ${CONNECT_MS} ms"
    echo "=========================================================="
fi
