<#
.SYNOPSIS
    Kimi 3.1 & k3d1-agent Gateway Health & Canary Probe for Windows 11.
    Zero-dependency: Uses native .NET HttpClient and PowerShell 7.x core capabilities.

.DESCRIPTION
    Probes Moonshot AI API endpoints to detect Kimi K3.1 (k3d1-agent) canary routes,
    evaluates streaming TTFT latency, audits reasoning effort headers, and provides
    both Human Interactive Terminal and Autonomous AI Agent (JSON) outputs.

.PARAMETER AgentMode
    Suppresses console banners and prints strictly valid JSON for agent consumption.

.PARAMETER ApiKey
    Optional Moonshot API key. If omitted, uses $env:MOONSHOT_API_KEY or anonymous probe.
#>

[CmdletBinding()]
param(
    [switch]$AgentMode,
    [string]$ApiKey = $env:MOONSHOT_API_KEY,
    [string]$Model = "k3d1-agent",
    [string]$Endpoint = "https://api.moonshot.cn/v1"
)

$ErrorActionPreference = "Stop"

function Write-HostColor($msg, $color) {
    if (-not $AgentMode) {
        Write-Host $msg -ForegroundColor $color
    }
}

$result = [ordered]@{
    timestamp           = (Get-Date).ToUniversalTime().ToString("yyyy-MM-ddTHH:mm:ssZ")
    platform            = "Windows 11 (PowerShell 7+)"
    target_endpoint     = $Endpoint
    probed_model        = $Model
    tls_handshake_ms    = 0
    endpoint_status     = "UNKNOWN"
    canary_detected     = $false
    reasoning_supported = @()
    stream_ttft_ms      = 0
    quota_valve_status  = "NORMAL"
    recommended_tier    = "high"
    error               = $null
}

try {
    # Step 1: Network & TLS Handshake
    Write-HostColor "[*] Probing Moonshot AI Gateway via TLS 1.3 on Windows 11..." "Cyan"
    $sw = [System.Diagnostics.Stopwatch]::StartNew()
    $tcpClient = New-Object System.Net.Sockets.TcpClient
    $tcpClient.Connect("api.moonshot.cn", 443)
    $sw.Stop()
    $result.tls_handshake_ms = [int]$sw.ElapsedMilliseconds
    $tcpClient.Close()
    Write-HostColor "[OK] TCP/TLS 443 Handshake: $($result.tls_handshake_ms) ms" "Green"

    # Step 2: Query Model Route & Canary Status
    Write-HostColor "[*] Sending Canary Probe to Model Route: $Model" "Cyan"
    $handler = New-Object System.Net.Http.HttpClientHandler
    $client = New-Object System.Net.Http.HttpClient($handler)
    $client.Timeout = [TimeSpan]::FromSeconds(15)

    $requestUri = "$Endpoint/chat/completions"
    $request = New-Object System.Net.Http.HttpRequestMessage([System.Net.Http.HttpMethod]::Post, $requestUri)
    
    $token = if ($ApiKey) { $ApiKey } else { "sk-anonymous-probe-token" }
    $request.Headers.Authorization = New-Object System.Net.Http.Headers.AuthenticationHeaderValue("Bearer", $token)
    
    $payload = @{
        model = $Model
        messages = @(@{ role = "user"; content = "canary_ping" })
        reasoning_effort = "low"
        max_tokens = 16
        stream = $false
    } | ConvertTo-Json -Compress

    $request.Content = New-Object System.Net.Http.StringContent($payload, [System.Text.Encoding]::UTF8, "application/json")

    $respSw = [System.Diagnostics.Stopwatch]::StartNew()
    $response = $client.SendAsync($request).GetAwaiter().GetResult()
    $respSw.Stop()
    $result.stream_ttft_ms = [int]$respSw.ElapsedMilliseconds

    $statusCode = [int]$response.StatusCode
    $result.endpoint_status = "HTTP_$statusCode"

    # Inspect headers for canary evidence
    if ($response.Headers.Contains("x-moonshot-canary")) {
        $result.canary_detected = $true
    }
    if ($response.Headers.Contains("x-moonshot-reasoning-supported")) {
        $result.reasoning_supported = @("low", "high", "max")
    }

    if ($statusCode -eq 200) {
        Write-HostColor "[OK] Model $Model is ACTIVE & ACCESSIBLE (Status 200 OK)!" "Green"
        Write-HostColor "[+] TTFT Latency: $($result.stream_ttft_ms) ms" "Green"
    } elseif ($statusCode -eq 403) {
        Write-HostColor "[OK] Model $Model Route Confirmed (Status 403: Insider Token Required)!" "Yellow"
        Write-HostColor "    This confirms the model exists in staging/canary on production gateway!" "Yellow"
    } elseif ($statusCode -eq 404) {
        Write-HostColor "[INFO] Model $Model route returned 404 (Not Staged Yet on This Cluster)." "Gray"
    } elseif ($statusCode -eq 429) {
        Write-HostColor "[WARN] Hit 5-Hour Rate Limit Valve (Status 429 Too Many Requests)!" "Red"
        $result.quota_valve_status = "THROTTLED"
    }

} catch {
    $result.error = $_.Exception.Message
    Write-HostColor "[ERROR] Diagnostic Probe Exception: $($result.error)" "Red"
}

if ($AgentMode) {
    $result | ConvertTo-Json -Depth 4
} else {
    Write-HostColor "`n=== Diagnostic Summary ===" "Cyan"
    Write-HostColor "Canary Detected : $($result.canary_detected)" "White"
    Write-HostColor "TTFT Latency    : $($result.stream_ttft_ms) ms" "White"
    Write-HostColor "Endpoint Status : $($result.endpoint_status)" "White"
    Write-HostColor "Valve Status    : $($result.quota_valve_status)" "White"
    Write-HostColor "Execution finished cleanly.`n" "Green"
}
