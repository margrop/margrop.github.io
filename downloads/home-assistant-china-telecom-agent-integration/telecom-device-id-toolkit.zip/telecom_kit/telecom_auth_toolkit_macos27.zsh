#!/usr/bin/env zsh
# Telecom Device Auth & HA Integration Toolkit for macOS 27
# Pure local execution - zero third-party cloud dependencies
set -euo pipefail

AGENT_MODE=0
if [[ "${1:-}" == "--agent" || "${1:-}" == "--json" ]]; then
  AGENT_MODE=1
  shift
fi

CMD="${1:-help}"
HA_URL="${HOME_ASSISTANT_URL:-http://homeassistant.local:8123}"
HA_TOKEN="${HOME_ASSISTANT_TOKEN:-}"
AUTH_PORT="${AUTH_PORT:-8765}"

log() { if [[ $AGENT_MODE -eq 0 ]]; then echo "$1"; fi }
fail() { echo "$1" >&2; exit 1; }

check_deps() {
  command -v python3 >/dev/null 2>&1 || fail "python3 is required."
  command -v curl >/dev/null 2>&1 || fail "curl is required."
}

case "$CMD" in
  check)
    check_deps
    log "Checking connectivity to China Telecom official endpoints..."
    curl -s --connect-timeout 5 -I https://appgologinsz.189.cn >/dev/null 2>&1 && log "✓ 189.cn login gateway reachable" || log "! Warning: 189.cn gateway connection delayed"
    
    if [[ -n "$HA_TOKEN" ]]; then
      log "Checking Home Assistant connectivity ($HA_URL)..."
      HTTP_STATUS=$(curl -s -o /dev/null -w "%{http_code}" -H "Authorization: Bearer $HA_TOKEN" "$HA_URL/api/config" || true)
      if [[ "$HTTP_STATUS" == "200" ]]; then
        log "✓ Home Assistant API authenticated successfully (HTTP 200)"
      else
        log "! Warning: Home Assistant API returned HTTP $HTTP_STATUS"
      fi
    else
      log "! Note: HOME_ASSISTANT_TOKEN not exported; HA API checks skipped."
    fi

    if [[ $AGENT_MODE -eq 1 ]]; then
      echo '{"status":"ok","official_gateway":true,"ha_url":"'$HA_URL'"}'
    fi
    ;;

  serve)
    check_deps
    log "Starting local device authorization server on port $AUTH_PORT..."
    log "Security Notice: Process operates 100% in local memory with 10-minute token expiration."
    exec python3 -m tools.telecom_auth --host 0.0.0.0 --port "$AUTH_PORT"
    ;;

  verify)
    check_deps
    [[ -n "$HA_TOKEN" ]] || fail "HOME_ASSISTANT_TOKEN is required for verification."
    log "Verifying china_telecom entity states from Home Assistant..."
    python3 - <<PY
import os, sys, json, urllib.request, re

url = os.environ.get("HOME_ASSISTANT_URL", "http://homeassistant.local:8123").rstrip("/") + "/api/states"
token = os.environ.get("HOME_ASSISTANT_TOKEN", "")

req = urllib.request.Request(url, headers={"Authorization": "Bearer " + token})
try:
    with urllib.request.urlopen(req, timeout=10) as resp:
        states = json.loads(resp.read().decode())
except Exception as e:
    print(f"Error querying HA API: {e}", file=sys.stderr)
    sys.exit(1)

telecom_states = [s for s in states if "telecom" in s["entity_id"] or "153_" in s["entity_id"] or "189_" in s["entity_id"]]
if not telecom_states:
    print("No telecom entities found.", file=sys.stderr)
    sys.exit(1)

active = [s for s in telecom_states if s["state"] not in ("unavailable", "unknown")]
print(f"Total Telecom Entities: {len(telecom_states)}, Active with Real Data: {len(active)}")
for s in telecom_states[:6]:
    fn = re.sub(r'(\d{3})\d{4}(\d{4})', r'\1****\2', s.get("attributes", {}).get("friendly_name", ""))
    val = s["state"]
    unit = s.get("attributes", {}).get("unit_of_measurement", "")
    print(f"  • {fn}: {val} {unit}")
PY
    ;;

  *)
    echo "Usage: $0 [--agent] {check|serve|verify}"
    echo ""
    echo "Commands:"
    echo "  check   - Verify network, Python runtime, and HA API status"
    echo "  serve   - Launch local device authorization web tool"
    echo "  verify  - Read-only check of HA telecom entities and sensor values"
    ;;
esac
