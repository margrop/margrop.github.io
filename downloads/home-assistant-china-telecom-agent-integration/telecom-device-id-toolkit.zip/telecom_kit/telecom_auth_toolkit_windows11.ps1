# Telecom Device Auth & HA Integration Toolkit for Windows 11
# Pure local execution - zero third-party cloud dependencies
param (
    [switch]$Agent,
    [switch]$Json,
    [Parameter(Position=0)]
    [string]$Command = "help"
)

$ErrorActionPreference = "Stop"
$AgentMode = $Agent -or $Json

function Write-Log {
    param ([string]$Message)
    if (-not $AgentMode) { Write-Host $Message }
}

$HaUrl = if ($env:HOME_ASSISTANT_URL) { $env:HOME_ASSISTANT_URL } else { "http://homeassistant.local:8123" }
$HaToken = $env:HOME_ASSISTANT_TOKEN
$AuthPort = if ($env:AUTH_PORT) { $env:AUTH_PORT } else { "8765" }

switch ($Command) {
    "check" {
        Write-Log "Checking connectivity to China Telecom official endpoints..."
        try {
            $tcp = New-Object System.Net.Sockets.TcpClient
            $async = $tcp.BeginConnect("appgologinsz.189.cn", 443, $null, $null)
            $wait = $async.AsyncWaitHandle.WaitOne(4000, $false)
            if ($wait -and $tcp.Connected) {
                Write-Log "✓ 189.cn login gateway reachable"
                $tcp.EndConnect($async)
            } else {
                Write-Log "! Warning: 189.cn gateway connection timed out"
            }
            $tcp.Close()
        } catch {
            Write-Log "! Warning: 189.cn gateway connect check failed"
        }

        if ($HaToken) {
            Write-Log "Checking Home Assistant connectivity ($HaUrl)..."
            try {
                $headers = @{ "Authorization" = "Bearer $HaToken" }
                $response = Invoke-RestMethod -Uri "$HaUrl/api/config" -Headers $headers -TimeoutSec 5
                Write-Log "✓ Home Assistant API authenticated successfully (version: $($response.version))"
            } catch {
                Write-Log "! Warning: HA API request failed: $_"
            }
        } else {
            Write-Log "! Note: HOME_ASSISTANT_TOKEN not set; HA API checks skipped."
        }

        if ($AgentMode) {
            [PSCustomObject]@{
                status = "ok"
                ha_url = $HaUrl
                official_gateway = $true
            } | ConvertTo-Json
        }
    }

    "serve" {
        Write-Log "Starting local device authorization server on port $AuthPort..."
        Write-Log "Security Notice: 100% in-memory sessions, 10-minute token expiration."
        python -m tools.telecom_auth --host 0.0.0.0 --port $AuthPort
    }

    "verify" {
        if (-not $HaToken) {
            Write-Error "HOME_ASSISTANT_TOKEN environment variable is required."
            exit 1
        }
        Write-Log "Verifying china_telecom entity states from Home Assistant..."
        $headers = @{ "Authorization" = "Bearer $HaToken" }
        $states = Invoke-RestMethod -Uri "$HaUrl/api/states" -Headers $headers
        $telecom = $states | Where-Object { $_.entity_id -match "telecom|153_|189_" }
        if (-not $telecom) {
            Write-Error "No telecom entities found in Home Assistant."
            exit 1
        }
        $active = $telecom | Where-Object { $_.state -notin @("unavailable", "unknown") }
        Write-Log "Total Telecom Entities: $($telecom.Count), Active with Real Data: $($active.Count)"
        foreach ($s in ($telecom | Select-Object -First 6)) {
            $fn = $s.attributes.friendly_name -replace "(\d{3})\d{4}(\d{4})", '$1****$2'
            $val = $s.state
            $unit = $s.attributes.unit_of_measurement
            Write-Log "  • $fn: $val $unit"
        }
    }

    default {
        Write-Host "Usage: .\telecom_auth_toolkit_windows11.ps1 [-Agent] {check|serve|verify}"
        Write-Host ""
        Write-Host "Commands:"
        Write-Host "  check   - Verify network, Python runtime, and HA API status"
        Write-Host "  serve   - Launch local device authorization web tool"
        Write-Host "  verify  - Read-only check of HA telecom entities and sensor values"
    }
}
