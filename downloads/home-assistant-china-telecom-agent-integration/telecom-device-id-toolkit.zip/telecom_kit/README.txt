Telecom Phone Device ID Toolkit for Home Assistant
===================================================

This toolkit helps you obtain the official China Telecom DeviceId and
integrate carrier balance and cellular data sensors into Home Assistant
without leaking your phone number, password, or SMS codes to any third-party cloud.

Files included:
- telecom_auth_toolkit_macos27.zsh    (macOS 27 Zsh entrypoint)
- telecom_auth_toolkit_ubuntu2604.sh  (Ubuntu 26.04 Bash entrypoint)
- telecom_auth_toolkit_windows11.ps1  (Windows 11 PowerShell entrypoint)

Prerequisites:
- Python 3.10+ with requests, pycryptodome

Environment Variables (Optional):
- HOME_ASSISTANT_URL   (default: http://homeassistant.local:8123)
- HOME_ASSISTANT_TOKEN (Home Assistant long-lived access token)
- AUTH_PORT            (default: 8765)

Usage:
1. Run './telecom_auth_toolkit_<os> check' to verify connectivity.
2. Run './telecom_auth_toolkit_<os> serve' to start local auth tool.
3. Open the random-token URL shown in the console, drag the slider, enter SMS code.
4. Copy the DeviceId into your Home Assistant china_telecom integration.
5. Run './telecom_auth_toolkit_<os> verify' to confirm your sensors are live.
